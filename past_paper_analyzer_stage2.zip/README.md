# O-Level Past-Paper Analyzer (Flask)

Flask project for Web Engineering (CSE601330): upload O-level past papers, extract and classify
questions, and rank topics by likelihood with backtested evidence. **48 SQLAlchemy tables**
(rubric minimum is 40) connected through 67 foreign keys.

AI assistance (Claude) was used to generate parts of this code; see the project guide.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Seed data and run

```bash
flask --app run db upgrade        # after the migration steps below
flask --app run seed              # boards, subjects, topics, demo accounts
flask --app run run --debug
```

Demo accounts (created by the seed): `admin` / `Demo#12345` and `student` / `Demo#12345`.
The Physics topic tree is a starter; replace it with the official syllabus.

## Verify the schema

```bash
python -m scripts.verify_schema    # builds every table, checks the 40-table rule
pytest                             # relationship, cascade and constraint tests
```

## Create the real database with migrations

```bash
flask --app run db init
flask --app run db migrate -m "initial schema"
flask --app run db upgrade
```

## Environment variables

| Variable       | Purpose                              | Default                     |
|----------------|--------------------------------------|-----------------------------|
| `SECRET_KEY`   | Signs session cookies                | `change-me-in-production`   |
| `DATABASE_URL` | SQLAlchemy connection string         | `sqlite:///past_paper.db`   |

## Layout

```
app/models/    identity, exam, syllabus, papers, questions, analytics, student, system
app/models/__init__.py   ALL_MODELS registry (used by the generic admin CRUD)
scripts/verify_schema.py rubric policy check
tests/                   pytest suite
```
