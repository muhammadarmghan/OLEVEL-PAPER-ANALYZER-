"""Reference data and demo accounts. Idempotent: safe to run repeatedly.

The topic tree is a STARTER for Physics (5054). Replace/extend it with the
official Cambridge syllabus before relying on topic statistics.
"""
from .extensions import db
from .models import (
    CommandWord, ExamBoard, ExamSession, PaperComponent, PaperVariant, Qualification,
    QuestionType, Role, Subject, SyllabusVersion, Topic, TopicKeyword, Unit, User,
)

ROLES = ["student", "contributor", "admin"]
QUESTION_TYPES = {"mcq": "Multiple choice", "structured": "Structured", "essay": "Essay", "numerical": "Numerical"}
COMMAND_WORDS = ["state", "describe", "explain", "calculate", "define", "suggest", "compare", "determine", "name", "outline"]
SUBJECTS = {"5054": "Physics", "5070": "Chemistry"}
COMPONENTS = [(1, "Multiple Choice", "mcq", 40), (2, "Theory", "structured", 80)]
YEARS, SERIES = range(2018, 2025), ("s", "w")

PHYSICS_TOPICS = {  # unit number -> (title, [(code, title, keywords)])
    1: ("Motion, forces and energy", [
        ("1.1", "Physical quantities and measurement", ["measurement", "vernier", "micrometer"]),
        ("1.2", "Motion", ["speed", "velocity", "acceleration"]),
        ("1.5", "Forces", ["force", "newton", "friction", "resultant"]),
        ("1.7", "Energy, work and power", ["work", "power", "kinetic", "efficiency"]),
        ("1.8", "Pressure", ["pressure", "manometer"])]),
    2: ("Thermal physics", [
        ("2.1", "Kinetic particle model of matter", ["particles", "gas pressure", "brownian"]),
        ("2.3", "Transfer of thermal energy", ["conduction", "convection", "radiation"])]),
    3: ("Waves", [
        ("3.1", "General properties of waves", ["wavelength", "frequency", "amplitude"]),
        ("3.2", "Light", ["reflection", "refraction", "lens"]),
        ("3.4", "Sound", ["echo", "ultrasound", "pitch"])]),
    4: ("Electricity and magnetism", [
        ("4.2", "Electrical quantities", ["current", "voltage", "resistance"]),
        ("4.3", "Electric circuits", ["circuit", "series", "parallel", "resistor"]),
        ("4.5", "Electromagnetic effects", ["transformer", "induction", "motor"])]),
    5: ("Nuclear physics", [("5.2", "Radioactivity", ["alpha", "beta", "gamma", "half-life"])]),
    6: ("Space physics", [("6.1", "Earth and the Solar System", ["orbit", "planet", "moon"])]),
}


def get_or_create(model, defaults=None, **lookup):
    obj = model.query.filter_by(**lookup).first()
    if obj is None:
        obj = model(**lookup, **(defaults or {}))
        db.session.add(obj)
        db.session.flush()
    return obj


def seed_all():
    roles = {name: get_or_create(Role, name=name) for name in ROLES}
    for code, name in QUESTION_TYPES.items():
        get_or_create(QuestionType, code=code, defaults={"name": name})
    for word in COMMAND_WORDS:
        get_or_create(CommandWord, word=word)

    board = get_or_create(ExamBoard, short_code="CAIE", defaults={"name": "Cambridge Assessment International Education"})
    qual = get_or_create(Qualification, board_id=board.id, name="O Level")
    for year in YEARS:
        for series in SERIES:
            get_or_create(ExamSession, board_id=board.id, year=year, series_code=series)

    for code, name in SUBJECTS.items():
        subject = get_or_create(Subject, qualification_id=qual.id, code=code, defaults={"name": name})
        for number, comp_name, style, marks in COMPONENTS:
            comp = get_or_create(PaperComponent, subject_id=subject.id, paper_number=number,
                                 defaults={"name": comp_name, "question_style": style, "total_marks": marks})
            for variant in (1, 2, 3):
                get_or_create(PaperVariant, component_id=comp.id, variant_number=variant)
        get_or_create(SyllabusVersion, subject_id=subject.id, version_label="starter",
                      defaults={"valid_from_year": 2023, "is_current": True})

    physics = Subject.query.filter_by(code="5054").one()
    version = physics.syllabus_versions[0]
    for number, (title, topics) in PHYSICS_TOPICS.items():
        unit = get_or_create(Unit, syllabus_version_id=version.id, number=number, defaults={"title": title})
        for order, (code, topic_title, keywords) in enumerate(topics):
            topic = get_or_create(Topic, unit_id=unit.id, code=code,
                                  defaults={"title": topic_title, "display_order": order})
            for kw in keywords:
                get_or_create(TopicKeyword, topic_id=topic.id, keyword=kw)

    for username, role in (("admin", "admin"), ("contributor", "contributor"), ("student", "student")):
        if not User.query.filter_by(username=username).first():
            user = User(username=username, email=f"{username}@example.com")
            user.set_password("Demo#12345")
            user.roles.append(roles[role])
            db.session.add(user)
    db.session.commit()
