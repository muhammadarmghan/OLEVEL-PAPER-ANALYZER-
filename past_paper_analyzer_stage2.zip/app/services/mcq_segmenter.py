"""Split the text of a multiple-choice question paper into numbered questions."""
import re

NOISE = [re.compile(p, re.IGNORECASE) for p in (
    r"^©\s*UCLES", r"^\[?\s*Turn over\s*\]?$", r"^\d{4}/\d{2}/[A-Z]/[A-Z]/\d{2}",
    r"^BLANK PAGE$", r"^\*?\d{8,}\*?$", r"^Permission to reproduce", r"^DO NOT WRITE",
)]
Q_START = re.compile(r"^(\d{1,2})(?:\s+(.*))?$")
OPTION = re.compile(r"^([A-D])(?:\s+(.*))?$")
LETTERS = "ABCD"


def _clean_lines(text: str) -> list[str]:
    lines = []
    for raw in text.splitlines():
        line = re.sub(r"\s+", " ", raw).strip()
        if line and not any(p.search(line) for p in NOISE):
            lines.append(line)
    return lines


def _is_option_a(lines: list[str], idx: int, window: int = 8) -> bool:
    """A line starting with 'A ...' is option A only if option B follows soon AND no other
    'A ...' line sits in between (that nearer line would be the real option A; this one is stem text)."""
    for offset, ln in enumerate(lines[idx + 1: idx + 1 + window], start=1):
        if re.match(r"^B(\s|$)", ln):
            return True
        if re.match(r"^A(\s|$)", ln):
            return False
    return False


def segment_mcq(text: str) -> list[dict]:
    """Return [{'number', 'text', 'options': {'A':..}, 'complete': bool}, ...]."""
    lines = _clean_lines(text)
    questions, current, expected = [], None, 1
    for idx, line in enumerate(lines):
        start = Q_START.match(line)
        # A new question starts only when the number is the expected one AND the
        # previous question already collected all four options.
        if start and int(start[1]) == expected and (current is None or len(current["options"]) == 4):
            current = {"number": expected, "stem": [start[2] or ""], "options": {}, "open": "stem"}
            questions.append(current)
            expected += 1
            continue
        if current is None:
            continue
        letter = LETTERS[len(current["options"])] if len(current["options"]) < 4 else None
        opt = OPTION.match(line)
        if letter and opt and opt[1] == letter and (letter != "A" or _is_option_a(lines, idx)):
            current["options"][letter] = opt[2] or ""
            current["open"] = letter
            continue
        if current["open"] == "stem":
            current["stem"].append(line)
        else:
            current["options"][current["open"]] = (current["options"][current["open"]] + " " + line).strip()
    return [
        {"number": q["number"], "text": " ".join(s for s in q["stem"] if s).strip(),
         "options": q["options"], "complete": len(q["options"]) == 4}
        for q in questions
    ]


def validate_questions(questions: list[dict], expected_count: int = 40) -> list[str]:
    """Human-readable problems; an empty list means the paper looks right."""
    problems = []
    if len(questions) != expected_count:
        problems.append(f"Found {len(questions)} questions, expected {expected_count}.")
    problems += [f"Question {q['number']} has {len(q['options'])} options." for q in questions if not q["complete"]]
    return problems
