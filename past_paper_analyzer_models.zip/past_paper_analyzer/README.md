# O-Level Past-Paper Analyzer (Flask)

Database layer for the Web Engineering (CSE601330) Flask project: **48 SQLAlchemy
tables** (rubric minimum is 40) connected through 67 foreign keys.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Verify the schema

```bash
python -m scripts.verify_schema    # builds every table, checks the 40-table rule
pytest                             # relationship, cascade and constraint tests
```

## Create the real database with migrations

```bash
flask --app run db init
flask --app run db migrate -m "initial schema"
flask --app run db upgrade
```

## Environment variables

| Variable       | Purpose                              | Default                     |
|----------------|--------------------------------------|-----------------------------|
| `SECRET_KEY`   | Signs session cookies                | `change-me-in-production`   |
| `DATABASE_URL` | SQLAlchemy connection string         | `sqlite:///past_paper.db`   |

## Layout

```
app/models/    identity, exam, syllabus, papers, questions, analytics, student, system
app/models/__init__.py   ALL_MODELS registry (used by the generic admin CRUD)
scripts/verify_schema.py rubric policy check
tests/                   pytest suite
```
