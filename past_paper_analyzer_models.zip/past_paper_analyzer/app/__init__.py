from flask import Flask

from config import CONFIGS

from .extensions import db, migrate


def create_app(config_name: str = "default") -> Flask:
    """Application factory."""
    app = Flask(__name__)
    app.config.from_object(CONFIGS[config_name])

    db.init_app(app)
    migrate.init_app(app, db)

    from . import models  # noqa: F401  (registers every model with SQLAlchemy)

    return app
